package com.cric.scorer.PersonaServices.Impl;

import com.cric.scorer.EntityServices.MatchDetailsService;
import com.cric.scorer.PersonaServices.GeneralServices;
import com.cric.scorer.Repository.MatchDetailsRepo;
import com.cric.scorer.entity.MatchDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GeneralServicesImpl implements GeneralServices {
    @Autowired
    private MatchDetailsService matchDetailsService;
    @Override
    public MatchDetails getMatchDetails(long id) {
        return this.matchDetailsService.findById(id);
    }
}
