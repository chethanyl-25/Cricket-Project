package com.cric.scorer.DTOs.output;

import java.math.BigInteger;

public interface BallsPlayed {
    int getRuns();
    Long getBallId();
}
