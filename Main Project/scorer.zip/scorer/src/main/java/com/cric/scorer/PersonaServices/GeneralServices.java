package com.cric.scorer.PersonaServices;

import com.cric.scorer.entity.MatchDetails;

public interface GeneralServices {
    public MatchDetails getMatchDetails(long id);
}
