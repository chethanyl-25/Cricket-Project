package com.cric.scorer.EntityServices;

import com.cric.scorer.entity.ScoreDetails;

public interface ScoreDetailsService {
    ScoreDetails save(ScoreDetails scoreDetails);
}
