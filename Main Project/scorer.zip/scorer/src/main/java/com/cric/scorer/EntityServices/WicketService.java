package com.cric.scorer.EntityServices;

import com.cric.scorer.entity.Wicket;

public interface WicketService {
    public Wicket save(Wicket wicket);
}
