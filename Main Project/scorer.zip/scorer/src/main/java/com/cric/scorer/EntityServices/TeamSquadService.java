package com.cric.scorer.EntityServices;

import com.cric.scorer.entity.TeamSquad;

public interface TeamSquadService {
    public TeamSquad save(TeamSquad teamSquad);
}
