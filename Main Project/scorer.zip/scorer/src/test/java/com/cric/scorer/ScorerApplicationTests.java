package com.cric.scorer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScorerApplicationTests {

	@Test
	void contextLoads() {
	}

}
